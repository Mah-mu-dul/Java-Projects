package Order;

import java.util.ArrayList;

public class java {

    private int orderId;
    private ArrayList productIds;
}
    